export default {
    apiKey: "AIzaSyDgrUIWpvWUfvER_YzoS9genSomfj2IH4k",
    authDomain: "dashboards-31365.firebaseapp.com",
    databaseURL: "https://dashboards-31365.firebaseio.com",
    projectId: "dashboards-31365",
    storageBucket: "",
    messagingSenderId: "789340824834"
};