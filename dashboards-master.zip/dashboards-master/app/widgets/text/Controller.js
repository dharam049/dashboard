import { Controller } from "cx/ui";

export default class extends Controller {}
